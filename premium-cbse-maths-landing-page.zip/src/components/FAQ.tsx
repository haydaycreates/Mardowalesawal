import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Plus, Minus, HelpCircle } from "lucide-react";

const faqs = [
  {
    q: "Is this aligned with the latest CBSE Class 12 syllabus?",
    a: "Yes — 100%. Every question is mapped to the latest NCERT Class 12 syllabus and the 2025–26 CBSE board pattern. We update the question bank every week based on the latest board trends and student feedback.",
  },
  {
    q: "What does 'HOTS' mean? Which questions are 'mardo wale'?",
    a: "HOTS = Higher Order Thinking Skills. These are the 4–6 mark questions CBSE examiners love to ask — multi-step, concept-twisting and rarely solved by surface-level memorisation. Our 'Mardo' tier is the toughest 30% of those — exactly the kind boards ask to separate 90 from 99.",
  },
  {
    q: "Does this cover both Hindi and English mediums?",
    a: "Absolutely. Every solution is available in both Hindi and English. You can switch language any time, and even share Hindi solutions with your parents or tuition teacher.",
  },
  {
    q: "How does the AI doubt solver work?",
    a: "Type or paste any HOTS question, the AI gives you a step-by-step, 6-mark-style solution in under 4 seconds — exactly the way a CBSE examiner expects it to be answered. It's available 24×7 even on the free plan (with daily limits).",
  },
  {
    q: "Is it a one-time payment or subscription?",
    a: "Both. You can choose a monthly plan (₹199/mo for Boards Plus) or save 35% with our yearly plan (₹1,499/yr). All plans renew automatically and can be cancelled any time from your dashboard.",
  },
  {
    q: "What if I don't score well after using the app?",
    a: "We offer a 7-day, no-questions-asked refund — full amount returned. We've had less than 0.4% refund requests in 2025 because of the consistency the app drives, but the guarantee stands for every student.",
  },
  {
    q: "Will this help with JEE / competitive exams too?",
    a: "Our Topper Batch plan (₹349/mo) includes JEE Main & Advanced level HOTS from the same chapters. Boards Plus focuses on CBSE boards specifically.",
  },
  {
    q: "I'm in class 11 — should I start now?",
    a: "Yes! Solving 5–10 HOTS questions a week in class 11 gives you a massive head start for class 12 boards. We have a dedicated class 11 plan coming soon — subscribe to get early access.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 md:py-32">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />

      <div className="mx-auto max-w-4xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-violet-300">
            <HelpCircle className="h-3.5 w-3.5" />
            FAQ
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Questions,{" "}
            <span className="gradient-text-cool">answered.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            Everything students and parents ask — in one place.
          </p>
        </motion.div>

        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <motion.div
              key={f.q}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: (i % 4) * 0.05 }}
              className={`overflow-hidden rounded-2xl border transition-colors ${
                open === i
                  ? "border-white/15 bg-white/[0.04]"
                  : "border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04]"
              }`}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left md:px-6 md:py-5"
                aria-expanded={open === i}
              >
                <span className="text-base font-semibold text-white md:text-lg">
                  {f.q}
                </span>
                <span
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-all ${
                    open === i
                      ? "border-violet-400/40 bg-violet-500/15 text-violet-300"
                      : "border-white/10 bg-white/5 text-zinc-300"
                  }`}
                >
                  {open === i ? (
                    <Minus className="h-4 w-4" />
                  ) : (
                    <Plus className="h-4 w-4" />
                  )}
                </span>
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <div className="px-5 pb-5 text-sm leading-relaxed text-zinc-400 md:px-6 md:pb-6 md:text-base">
                      {f.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
