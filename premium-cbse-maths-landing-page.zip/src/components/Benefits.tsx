import { motion } from "framer-motion";
import {
  CheckCircle2,
  TrendingUp,
  Clock,
  Award,
  Heart,
  GraduationCap,
} from "lucide-react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Score 95+ in boards",
    desc: "Average jump of +18 marks after 30 days of focused practice on mardo wale sawaal.",
    stat: "+18",
    statLabel: "avg. marks",
  },
  {
    icon: Clock,
    title: "Save 4 hours every week",
    desc: "No more sifting through 300-page PDFs. Curated, focused, on-tap.",
    stat: "4h",
    statLabel: "saved weekly",
  },
  {
    icon: Award,
    title: "Become the class topper",
    desc: "Our 12-week plan has produced 1,400+ school toppers in this academic year alone.",
    stat: "1.4k",
    statLabel: "school toppers",
  },
];

const points = [
  "Aligned 100% with the latest CBSE Class 12 syllabus",
  "Practise the way CBSE actually tests you — HOTS, case-study, 6-mark",
  "Detailed, examiner-style solutions in Hindi & English",
  "Personalised revision plans, smart revision reminders",
  "Mock tests mirroring the latest board exam pattern",
  "Friendly student community — doubt-clearing, not late-night scrolling",
];

export default function Benefits() {
  return (
    <section className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">
              <Heart className="h-3.5 w-3.5" />
              Why students love it
            </span>
            <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
              From{" "}
              <span className="line-through decoration-pink-500/60 decoration-4">
                confused
              </span>{" "}
              to <span className="gradient-text-brand">confident.</span>
            </h2>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-zinc-400">
              Built by IIT & NIT alumni, validated by 7 CBSE toppers in 2025 —
              and tuned every single week based on the latest board trends.
            </p>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {benefits.map((b) => (
                <div
                  key={b.title}
                  className="glass rounded-2xl p-4"
                >
                  <div className="font-display text-2xl font-extrabold text-white">
                    {b.stat}
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-zinc-500">
                    {b.statLabel}
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-zinc-400">
                    {b.desc}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div className="glass-strong relative overflow-hidden rounded-3xl p-8 md:p-10">
              <div className="absolute -top-20 -right-20 h-60 w-60 rounded-full bg-gradient-to-br from-emerald-400 to-cyan-500 opacity-15 blur-3xl" />
              <div className="absolute -bottom-20 -left-20 h-60 w-60 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 opacity-15 blur-3xl" />
              <div className="relative">
                <div className="flex items-center gap-2">
                  <GraduationCap className="h-5 w-5 text-violet-300" />
                  <p className="text-sm font-semibold text-violet-300">
                    What you actually get
                  </p>
                </div>
                <h3 className="font-display mt-3 text-2xl font-bold text-white">
                  Every reason class 12 students stay.
                </h3>

                <ul className="mt-7 space-y-4">
                  {points.map((p) => (
                    <motion.li
                      key={p}
                      initial={{ opacity: 0, x: 10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4 }}
                      className="flex items-start gap-3"
                    >
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 shadow-lg shadow-emerald-500/30">
                        <CheckCircle2 className="h-3.5 w-3.5 text-white" strokeWidth={3} />
                      </span>
                      <span className="text-sm leading-relaxed text-zinc-200">
                        {p}
                      </span>
                    </motion.li>
                  ))}
                </ul>

                <div className="mt-9 flex items-center gap-4 rounded-2xl border border-white/10 bg-black/30 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/30">
                    <Award className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">97% would recommend</p>
                    <p className="text-xs text-zinc-400">
                      Based on 12,800+ verified student reviews
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
