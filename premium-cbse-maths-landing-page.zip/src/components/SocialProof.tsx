import { motion } from "framer-motion";

const logos = [
  "DPS R.K. Puram",
  "Delhi Public School",
  "Amity International",
  "Mayo College",
  "Modern School",
  "Vasant Valley",
  "Shriram School",
  "Ryan International",
  "Kendriya Vidyalaya",
  "Pathways World",
  "La Martiniere",
  "The Doon School",
];

export default function SocialProof() {
  return (
    <section className="relative py-16 md:py-20">
      <div className="mx-auto max-w-7xl px-5">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center text-xs font-medium uppercase tracking-[0.25em] text-zinc-500"
        >
          Trusted by toppers from India's leading schools
        </motion.p>

        <div className="relative mt-8 overflow-hidden">
          <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#06060b] to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#06060b] to-transparent" />
          <div className="flex w-[200%]">
            <div className="flex w-1/2 items-center justify-around gap-12 marquee-track">
              {[...logos, ...logos].map((logo, i) => (
                <div
                  key={i}
                  className="shrink-0 whitespace-nowrap font-display text-lg font-semibold text-zinc-500/80 transition-colors hover:text-zinc-300"
                >
                  {logo}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {[
            { num: "1,84,000+", label: "Active class 12 students" },
            { num: "6,500+", label: "Curated HOTS questions" },
            { num: "13", label: "Chapters, full syllabus" },
            { num: "96.4%", label: "Avg score after 30 days" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="glass rounded-2xl p-5 text-center md:p-6"
            >
              <div className="font-display text-3xl font-extrabold gradient-text md:text-4xl">
                {s.num}
              </div>
              <div className="mt-1.5 text-sm text-zinc-400">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
