import { motion } from "framer-motion";
import {
  Sparkles,
  CheckCircle2,
  CircleDot,
  MessageSquare,
  Lightbulb,
} from "lucide-react";

export default function Showcase() {
  return (
    <section
      id="showcase"
      className="relative py-24 md:py-32"
    >
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-fuchsia-300">
            Inside the app
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            A study experience{" "}
            <span className="gradient-text-brand">that feels alive.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            Beyond the questions, every feature is designed to mirror how
            great teachers teach — visual, contextual and brutally honest.
          </p>
        </motion.div>

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-12">
          {/* Big app mockup */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative lg:col-span-7"
          >
            <div className="glass-strong relative overflow-hidden rounded-3xl p-2">
              <div className="rounded-2xl bg-gradient-to-br from-[#0a0a14] to-[#0d0d1c] p-5 md:p-6">
                {/* browser-ish header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
                    <div className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
                  </div>
                  <div className="flex-1 px-4">
                    <div className="mx-auto h-7 max-w-md rounded-full bg-white/5 text-center">
                      <span className="font-mono text-[10px] text-zinc-500">
                        mardowalesawaal.app / ch7 / integrals / q-024
                      </span>
                    </div>
                  </div>
                  <div className="text-[10px] text-zinc-500">v 3.4</div>
                </div>

                {/* Question */}
                <div className="mt-6 grid gap-5 md:grid-cols-2">
                  <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                    <div className="flex items-center justify-between">
                      <span className="rounded-full bg-fuchsia-500/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-fuchsia-300 ring-1 ring-fuchsia-400/30">
                        HOTS • 6 marks
                      </span>
                      <span className="text-[10px] text-zinc-500">Q-024</span>
                    </div>
                    <p className="mt-4 text-sm leading-relaxed text-zinc-200">
                      Evaluate{" "}
                      <span className="gradient-text-brand font-semibold">
                        ∫<sub>0</sub>
                        <sup>π/4</sup> log(1 + tan x) dx
                      </span>{" "}
                      using the property of definite integrals.
                    </p>
                    <div className="mt-5 flex flex-wrap gap-2">
                      {[
                        "Hint: I = ∫ f(x) dx → use f(a+b−x)",
                        "Show 2 more hints",
                      ].map((h, idx) => (
                        <button
                          key={h}
                          className={`rounded-lg px-3 py-1.5 text-[11px] font-medium transition-colors ${
                            idx === 0
                              ? "bg-violet-500/15 text-violet-200 ring-1 ring-violet-400/30"
                              : "border border-white/10 text-zinc-400 hover:bg-white/5"
                          }`}
                        >
                          <Lightbulb className="mr-1 inline h-3 w-3" />
                          {h}
                        </button>
                      ))}
                    </div>
                    <div className="mt-5 flex items-center gap-2 rounded-xl border border-white/10 bg-black/30 p-3 text-xs text-zinc-400">
                      <CircleDot className="h-3.5 w-3.5 text-amber-400" />
                      Tip: Use the property I = ∫<sub>0</sub><sup>a</sup> f(x)
                      dx where a = π/4.
                    </div>
                  </div>

                  <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.04] p-5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-emerald-300" />
                        <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                          6-mark solution
                        </span>
                      </div>
                      <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300 ring-1 ring-emerald-400/30">
                        100% marks
                      </span>
                    </div>
                    <div className="mt-4 space-y-2">
                      {[
                        "Let I = ∫₀^(π/4) log(1 + tan x) dx ... (i)",
                        "Using property: I = ∫₀^(π/4) log(1 + tan(π/4 − x)) dx",
                        "On simplification: 2I = (π/4) · log 2",
                        "∴ I = (π/8) · log 2",
                      ].map((s, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-2 rounded-md border border-emerald-400/15 bg-emerald-400/[0.04] px-2.5 py-1.5 text-[11px] leading-relaxed text-emerald-100"
                        >
                          <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded bg-emerald-500/30 text-[9px] font-bold">
                            {idx + 1}
                          </span>
                          <span className="font-mono">{s}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 rounded-lg bg-emerald-400/15 px-3 py-2 text-[11px] font-bold text-emerald-200">
                      ∴ ∫ log(1 + tan x) dx = (π/8) log 2
                    </div>
                  </div>
                </div>

                {/* Bottom toolbar */}
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-white/5 pt-5">
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-zinc-400">Difficulty</span>
                    <div className="flex gap-1">
                      <span className="h-1.5 w-6 rounded-full bg-emerald-400" />
                      <span className="h-1.5 w-6 rounded-full bg-amber-400" />
                      <span className="h-1.5 w-6 rounded-full bg-rose-500" />
                    </div>
                    <span className="text-xs font-semibold text-rose-300">
                      Mardo
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-zinc-500">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                    Examiner-validated
                    <span className="hidden sm:inline">·</span>
                    <MessageSquare className="hidden h-3.5 w-3.5 sm:inline" />
                    <span className="hidden sm:inline">412 doubts cleared</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Side cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:col-span-5 lg:grid-cols-1">
            <FloatingCard
              icon="🔥"
              title="12-day streak"
              desc="You solved 48 mardo wale sawaal in a row. Don't break it!"
              delay={0.1}
              accent="from-orange-500 to-rose-500"
            />
            <FloatingCard
              icon="📈"
              title="+14 marks improvement"
              desc="Your mock test scores have risen 14% in the last 21 days."
              delay={0.2}
              accent="from-emerald-400 to-teal-500"
            />
            <FloatingCard
              icon="🤖"
              title="AI tutor, 3:42 AM"
              desc="Stuck on a Bernoulli DE at 3:42 AM? Get step-wise help instantly."
              delay={0.3}
              accent="from-violet-500 to-fuchsia-500"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function FloatingCard({
  icon,
  title,
  desc,
  delay,
  accent,
}: {
  icon: string;
  title: string;
  desc: string;
  delay: number;
  accent: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -4 }}
      className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-5"
    >
      <div
        className={`absolute -top-16 -right-16 h-32 w-32 rounded-full bg-gradient-to-br ${accent} opacity-25 blur-3xl`}
      />
      <div className="relative flex items-start gap-3.5">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10 text-xl">
          {icon}
        </div>
        <div>
          <p className="font-semibold text-white">{title}</p>
          <p className="mt-1 text-sm leading-relaxed text-zinc-400">{desc}</p>
        </div>
      </div>
    </motion.div>
  );
}
