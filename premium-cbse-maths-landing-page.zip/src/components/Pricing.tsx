import { motion } from "framer-motion";
import { useState } from "react";
import { Check, Sparkles, ArrowRight, ShieldCheck } from "lucide-react";

const plans = [
  {
    name: "Free",
    badge: null,
    priceM: 0,
    priceY: 0,
    desc: "Get a feel for mardo wale sawaal. Always free.",
    cta: "Start free",
    highlight: false,
    features: [
      "50 starter questions across chapters",
      "Full solutions with explanations",
      "Daily 1 HOTS question",
      "Basic streak tracking",
      "Community access",
    ],
  },
  {
    name: "Boards Plus",
    badge: "Most popular",
    priceM: 199,
    priceY: 1499,
    desc: "Everything 95+ scorers use. Boards cracked.",
    cta: "Go boards-plus",
    highlight: true,
    features: [
      "All 6,500+ questions — every chapter",
      "All 3 difficulty tiers (incl. Mardo)",
      "AI doubt solver, 24×7",
      "10 full-length mock papers",
      "Personal analytics & revision planner",
      "Hindi + English solutions",
      "Leaderboards & competitions",
    ],
  },
  {
    name: "Topper Batch",
    badge: "Best value",
    priceM: 349,
    priceY: 2499,
    desc: "For serious aspirants. JEE + boards covered.",
    cta: "Get topper batch",
    highlight: false,
    features: [
      "Everything in Boards Plus",
      "JEE Main & Advanced HOTS included",
      "1-on-1 mentor sessions · 4 / mo",
      "Weekly live doubt-clearing with IITian",
      "Printed solution handbook (shipped)",
      "Priority response on AI solver",
      "Early access to new chapters",
    ],
  },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="relative py-24 md:py-32">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-fuchsia-950/10 to-transparent" />

      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-300">
            Simple pricing
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            Less than a coffee.{" "}
            <span className="gradient-text-brand">More than a topper.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            Pick the plan that fits your goals. Change or cancel any time. Every
            plan comes with a 7-day, no-questions-asked refund.
          </p>

          <div className="mt-8 inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 p-1.5">
            <button
              onClick={() => setYearly(false)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition-all ${
                !yearly
                  ? "bg-white text-zinc-900 shadow"
                  : "text-zinc-300 hover:text-white"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setYearly(true)}
              className={`relative rounded-full px-5 py-2 text-sm font-semibold transition-all ${
                yearly
                  ? "bg-white text-zinc-900 shadow"
                  : "text-zinc-300 hover:text-white"
              }`}
            >
              Yearly
              <span className="absolute -top-2 -right-2 rounded-full bg-emerald-400 px-1.5 py-0.5 text-[9px] font-bold text-emerald-950 shadow-lg">
                −35%
              </span>
            </button>
          </div>
        </motion.div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {plans.map((p, i) => (
            <motion.div
              key={p.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: i * 0.1 }}
              className={`relative overflow-hidden rounded-3xl p-7 transition-all ${
                p.highlight
                  ? "border-2 border-violet-400/40 bg-gradient-to-br from-violet-500/10 via-fuchsia-500/10 to-pink-500/10 shadow-2xl shadow-fuchsia-500/30 lg:scale-[1.03]"
                  : "border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01]"
              }`}
            >
              {p.highlight && (
                <div className="absolute -top-32 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-fuchsia-500/30 blur-3xl" />
              )}
              {p.badge && (
                <div className="absolute top-5 right-5 inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-900 shadow-lg">
                  <Sparkles className="h-3 w-3" />
                  {p.badge}
                </div>
              )}
              <div className="relative">
                <h3 className="font-display text-xl font-bold text-white">
                  {p.name}
                </h3>
                <p className="mt-1.5 text-sm text-zinc-400">{p.desc}</p>

                <div className="mt-6 flex items-baseline gap-1.5">
                  <span className="font-display text-5xl font-extrabold text-white">
                    ₹{yearly ? p.priceY : p.priceM}
                  </span>
                  <span className="text-sm text-zinc-400">
                    /{yearly ? "year" : "month"}
                  </span>
                </div>
                {yearly && p.priceY > 0 && (
                  <p className="mt-1.5 text-xs text-emerald-300">
                    Save ₹{p.priceM * 12 - p.priceY} vs monthly
                  </p>
                )}

                <a
                  href="#cta"
                  className={`mt-7 inline-flex w-full items-center justify-center gap-2 rounded-2xl px-5 py-3.5 text-sm font-semibold transition-all ${
                    p.highlight
                      ? "bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 text-white shadow-lg shadow-fuchsia-500/40 hover:shadow-fuchsia-500/60"
                      : "border border-white/15 bg-white/5 text-white hover:bg-white/10"
                  }`}
                >
                  {p.cta}
                  <ArrowRight className="h-4 w-4" />
                </a>

                <ul className="mt-7 space-y-3 border-t border-white/5 pt-7">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500">
                        <Check className="h-3 w-3 text-white" strokeWidth={3.5} />
                      </span>
                      <span className="text-sm leading-relaxed text-zinc-300">
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-center gap-2 text-center text-xs text-zinc-500 sm:flex-row sm:gap-3">
          <ShieldCheck className="h-4 w-4 text-emerald-400" />
          <span>7-day refund guarantee</span>
          <span className="hidden sm:inline">·</span>
          <span>Razorpay secured payments</span>
          <span className="hidden sm:inline">·</span>
          <span>Cancel any time in one tap</span>
        </div>
      </div>
    </section>
  );
}
