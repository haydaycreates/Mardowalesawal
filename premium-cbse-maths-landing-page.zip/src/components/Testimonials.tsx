import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";

const reviews = [
  {
    name: "Aarav Sharma",
    role: "Class 12 • DPS R.K. Puram",
    avatar: "from-violet-500 to-fuchsia-500",
    score: "98/100",
    quote:
      "I used to panic looking at 6-mark HOTS integrals. After 3 weeks on Mardo Wale Sawaal, my boards mock went from 78 to 94. The step-by-step solutions feel like a private tutor in your pocket.",
    stars: 5,
  },
  {
    name: "Priya Patel",
    role: "Class 12 • Mayo College",
    avatar: "from-fuchsia-500 to-pink-500",
    score: "96/100",
    quote:
      "The 'mardo' difficulty tier is no joke — but the way concepts are broken down makes them click. I scored full marks in Probability and that's because of this app.",
    stars: 5,
  },
  {
    name: "Rohan Iyer",
    role: "Class 12 • Modern School",
    avatar: "from-pink-500 to-orange-500",
    score: "95/100",
    quote:
      "Differential Equations was my nightmare. The chapter-wise HOTS plus AI doubt solver is genuinely the best combo — I solved 240 questions in 14 days and boards mein 95 aa gaya.",
    stars: 5,
  },
  {
    name: "Saanvi Reddy",
    role: "Class 12 • Amity International",
    avatar: "from-amber-400 to-rose-500",
    score: "99/100",
    quote:
      "Best decision of my boards prep. The Hindi solutions helped my mom revise with me. I'm now a college topper and I still recommend this to every class 12 student.",
    stars: 5,
  },
  {
    name: "Vivaan Kapoor",
    role: "Class 12 • Vasant Valley",
    avatar: "from-emerald-400 to-teal-500",
    score: "97/100",
    quote:
      "Worth every rupee. The leaderboard pushed me to be consistent — 32-day streak, school topper in boards. Mardo wale sawaal is now genuinely my favourite study ritual.",
    stars: 5,
  },
  {
    name: "Ishaan Mehta",
    role: "Class 12 • Pathways World",
    avatar: "from-cyan-400 to-blue-500",
    score: "96/100",
    quote:
      "I tried 3 platforms. None matched this. The questions are weird in the best way — exactly the trick-questions boards love to throw. 10/10.",
    stars: 5,
  },
];

export default function Testimonials() {
  const [i, setI] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % reviews.length), 6000);
    return () => clearInterval(t);
  }, []);

  const r = reviews[i];

  return (
    <section id="testimonials" className="relative py-24 md:py-32">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-amber-300">
            <Star className="h-3.5 w-3.5 fill-amber-300" />
            Loved by class 12
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            Real students.{" "}
            <span className="gradient-text-brand">Real 95+.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            1,400+ school toppers in 2025 came from this app — here's what
            they had to say.
          </p>
        </motion.div>

        {/* Featured carousel */}
        <div className="mt-14">
          <motion.div
            key={r.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass-strong relative mx-auto max-w-4xl overflow-hidden rounded-3xl p-8 md:p-12"
          >
            <Quote className="absolute top-6 right-6 h-12 w-12 text-white/5" />
            <div className="flex flex-col items-start gap-6 md:flex-row md:items-center">
              <div
                className={`flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${r.avatar} shadow-xl shadow-fuchsia-500/20`}
              >
                <span className="font-display text-2xl font-bold text-white">
                  {r.name.split(" ").map((n) => n[0]).join("")}
                </span>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <div className="flex">
                    {Array.from({ length: r.stars }).map((_, idx) => (
                      <Star
                        key={idx}
                        className="h-4 w-4 fill-amber-400 text-amber-400"
                      />
                    ))}
                  </div>
                  <span className="text-xs text-zinc-500">•</span>
                  <span className="text-xs font-semibold text-emerald-300">
                    Scored {r.score}
                  </span>
                </div>
                <p className="mt-4 font-display text-xl leading-relaxed text-white md:text-2xl">
                  "{r.quote}"
                </p>
                <div className="mt-5">
                  <p className="font-semibold text-white">{r.name}</p>
                  <p className="text-sm text-zinc-400">{r.role}</p>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="mt-6 flex items-center justify-center gap-4">
            <button
              onClick={() => setI((p) => (p - 1 + reviews.length) % reviews.length)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-colors hover:bg-white/10"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              {reviews.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setI(idx)}
                  aria-label={`Go to testimonial ${idx + 1}`}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === i ? "w-8 bg-white" : "w-1.5 bg-white/20"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => setI((p) => (p + 1) % reviews.length)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-colors hover:bg-white/10"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Mini wall */}
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {reviews.slice(0, 6).map((rev, idx) => (
            <motion.div
              key={rev.name + idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: (idx % 3) * 0.1 }}
              className="glass rounded-2xl p-5 transition-colors hover:bg-white/[0.06]"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${rev.avatar} text-sm font-bold text-white`}
                >
                  {rev.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-white">
                    {rev.name}
                  </p>
                  <p className="truncate text-xs text-zinc-500">{rev.role}</p>
                </div>
                <span className="ml-auto rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-300 ring-1 ring-emerald-400/30">
                  {rev.score}
                </span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-zinc-400 line-clamp-3">
                "{rev.quote}"
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
