import { motion } from "framer-motion";
import { Compass, Brain, Rocket, Trophy } from "lucide-react";

const steps = [
  {
    icon: Compass,
    step: "01",
    title: "Pick your chapter",
    desc: "From Relations to Probability — every NCERT chapter is live with tiered question sets.",
    color: "from-violet-500 to-fuchsia-500",
  },
  {
    icon: Brain,
    step: "02",
    title: "Solve mardo wale sawaal",
    desc: "Attempt HOTS, board-pattern and concept-breaking questions. Hint available, full solution when you need it.",
    color: "from-fuchsia-500 to-pink-500",
  },
  {
    icon: Rocket,
    step: "03",
    title: "Read 6-mark-style solutions",
    desc: "Step-by-step, examiner-framed, with the why behind each move. Learn to present answers like a topper.",
    color: "from-pink-500 to-orange-500",
  },
  {
    icon: Trophy,
    step: "04",
    title: "Track. Improve. Top.",
    desc: "Personal analytics, streaks, leaderboards — see your climb to 95+ in real time.",
    color: "from-amber-400 to-rose-500",
  },
];

export default function HowItWorks() {
  return (
    <section id="how" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-cyan-300">
            How it works
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            Four steps.{" "}
            <span className="gradient-text-brand">Zero friction.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            From picking a chapter to scoring 95+ — every step is designed to
            feel lightweight, deliberate, and a little addictive.
          </p>
        </motion.div>

        <div className="relative mt-16">
          {/* Connecting line for desktop */}
          <div className="pointer-events-none absolute left-0 right-0 top-16 hidden lg:block">
            <div className="mx-auto h-px max-w-5xl bg-gradient-to-r from-transparent via-white/20 to-transparent" />
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.12 }}
                className="relative"
              >
                <div className="glass-strong group relative overflow-hidden rounded-3xl p-7 transition-transform hover:-translate-y-1">
                  <div
                    className={`absolute -top-24 -right-20 h-44 w-44 rounded-full bg-gradient-to-br ${s.color} opacity-20 blur-3xl transition-opacity group-hover:opacity-40`}
                  />
                  <div
                    className={`relative inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${s.color} shadow-lg`}
                  >
                    <s.icon className="h-7 w-7 text-white" strokeWidth={2.2} />
                  </div>
                  <div className="mt-5 font-mono text-xs font-semibold tracking-widest text-zinc-500">
                    STEP {s.step}
                  </div>
                  <h3 className="font-display mt-1.5 text-xl font-bold text-white">
                    {s.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">
                    {s.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
