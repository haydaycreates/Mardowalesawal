"use client";
import { motion } from "framer-motion";
import {
  Brain,
  Target,
  Sparkles,
  Zap,
  FileText,
  Trophy,
  BarChart3,
  Languages,
  BookOpenCheck,
} from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "Concept-first explanations",
    desc: "Every step is anchored to the underlying concept — so you understand why, not just how.",
    color: "from-violet-500 to-fuchsia-500",
    glow: "shadow-violet-500/30",
  },
  {
    icon: Target,
    title: "Board-marked HOTS",
    desc: "Real examiner framing, expected answer length and mark allocation — exactly what toppers practise.",
    color: "from-fuchsia-500 to-pink-500",
    glow: "shadow-fuchsia-500/30",
  },
  {
    icon: Sparkles,
    title: "Difficulty-tiered sets",
    desc: "Starter · Moderate · Mardo. Move up at your pace — every question has a smarter cousin.",
    color: "from-pink-500 to-rose-500",
    glow: "shadow-pink-500/30",
  },
  {
    icon: Zap,
    title: "Instant doubt-solving AI",
    desc: "Stuck on a step? Ask. Get a 6-mark-style solution in under 4 seconds, 24×7.",
    color: "from-amber-400 to-orange-500",
    glow: "shadow-amber-500/30",
  },
  {
    icon: FileText,
    title: "CBSE-pattern papers",
    desc: "Full-length & chapter-wise mock tests with detailed solution PDFs and answer keys.",
    color: "from-cyan-400 to-blue-500",
    glow: "shadow-cyan-500/30",
  },
  {
    icon: Trophy,
    title: "Leaderboards & streaks",
    desc: "Compete with friends, school toppers and the entire batch — gamified, never gimmicky.",
    color: "from-emerald-400 to-teal-500",
    glow: "shadow-emerald-500/30",
  },
  {
    icon: BarChart3,
    title: "Personal analytics",
    desc: "Chapter-wise strength map, time spent, accuracy trajectory — see exactly where to fix.",
    color: "from-indigo-400 to-violet-500",
    glow: "shadow-indigo-500/30",
  },
  {
    icon: Languages,
    title: "Hindi + English",
    desc: "Solutions in both languages — switch any time. Concepts stay universal, language adapts.",
    color: "from-orange-400 to-rose-500",
    glow: "shadow-orange-500/30",
  },
  {
    icon: BookOpenCheck,
    title: "NCERT-aligned, every line",
    desc: "Strictly mapped to the latest NCERT Class 12 syllabus — no out-of-scope noise.",
    color: "from-rose-400 to-fuchsia-500",
    glow: "shadow-rose-500/30",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 md:py-32">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-violet-300">
            <Sparkles className="h-3.5 w-3.5" />
            Features
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            Built for the{" "}
            <span className="gradient-text-brand">99% club.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            Everything you need to not just solve, but truly master the toughest
            questions that actually appear in your Class 12 boards.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.55, delay: (i % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -6 }}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-7 transition-colors hover:border-white/20"
            >
              <div
                className={`absolute -top-24 -right-20 h-44 w-44 rounded-full bg-gradient-to-br ${f.color} opacity-20 blur-3xl transition-opacity group-hover:opacity-40`}
              />
              <div
                className={`relative inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br ${f.color} shadow-lg ${f.glow}`}
              >
                <f.icon className="h-6 w-6 text-white" strokeWidth={2.2} />
              </div>
              <h3 className="font-display mt-5 text-lg font-bold text-white">
                {f.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                {f.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
