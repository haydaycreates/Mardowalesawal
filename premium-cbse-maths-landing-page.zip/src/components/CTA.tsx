import { motion } from "framer-motion";
import { ArrowRight, Sparkles, ShieldCheck, Star } from "lucide-react";

export default function CTA() {
  return (
    <section id="cta" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="relative overflow-hidden rounded-[2rem] border border-violet-400/30 bg-gradient-to-br from-violet-500/10 via-fuchsia-500/10 to-pink-500/10 p-10 text-center md:p-16"
        >
          {/* Glow */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fuchsia-500/30 blur-3xl" />
            <div className="absolute right-1/4 top-1/4 h-64 w-64 rounded-full bg-violet-500/30 blur-3xl" />
            <div className="absolute bottom-1/4 left-1/4 h-64 w-64 rounded-full bg-pink-500/30 blur-3xl" />
          </div>

          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-violet-200"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Boards 2026 starts in 60 days
          </motion.span>

          <h2 className="font-display mt-7 text-4xl font-extrabold tracking-tight text-white sm:text-6xl md:text-7xl">
            Your 95+ is a{" "}
            <span className="gradient-text-brand">decision away.</span>
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-zinc-300">
            Start solving mardo wale sawaal today. Free forever for the first
            50 questions — and 7-day full-refund if you don't love it.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href="#"
              className="group inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 px-9 py-4 text-base font-bold text-white shadow-2xl shadow-fuchsia-500/40 transition-all hover:scale-[1.03] hover:shadow-fuchsia-500/60"
            >
              <Sparkles className="h-5 w-5" />
              Start solving free now
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#pricing"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-9 py-4 text-base font-semibold text-white backdrop-blur transition-all hover:bg-white/10"
            >
              See pricing
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-zinc-400">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              7-day refund
            </div>
            <div className="flex items-center gap-2">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star
                    key={i}
                    className="h-3.5 w-3.5 fill-amber-400 text-amber-400"
                  />
                ))}
              </div>
              <span>4.9 · 12,800 reviews</span>
            </div>
            <div>🇮🇳 Made in India, for CBSE</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
