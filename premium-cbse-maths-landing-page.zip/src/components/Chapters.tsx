import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { ArrowRight, Check } from "lucide-react";

const chapters = [
  {
    code: "Ch 1",
    title: "Relations and Functions",
    questions: 412,
    diff: "Moderate",
    color: "from-violet-500 to-fuchsia-500",
  },
  {
    code: "Ch 2",
    title: "Inverse Trigonometric Functions",
    questions: 286,
    diff: "Mardo",
    color: "from-fuchsia-500 to-pink-500",
  },
  {
    code: "Ch 3",
    title: "Matrices",
    questions: 354,
    diff: "Moderate",
    color: "from-pink-500 to-rose-500",
  },
  {
    code: "Ch 4",
    title: "Determinants",
    questions: 478,
    diff: "Mardo",
    color: "from-rose-500 to-orange-500",
  },
  {
    code: "Ch 5",
    title: "Continuity & Differentiability",
    questions: 562,
    diff: "Mardo",
    color: "from-amber-400 to-orange-500",
  },
  {
    code: "Ch 6",
    title: "Application of Derivatives",
    questions: 638,
    diff: "Mardo",
    color: "from-orange-400 to-pink-500",
  },
  {
    code: "Ch 7",
    title: "Integrals",
    questions: 712,
    diff: "Mardo",
    color: "from-violet-500 to-indigo-500",
  },
  {
    code: "Ch 8",
    title: "Application of Integrals",
    questions: 384,
    diff: "Moderate",
    color: "from-cyan-500 to-blue-500",
  },
  {
    code: "Ch 9",
    title: "Differential Equations",
    questions: 524,
    diff: "Mardo",
    color: "from-indigo-500 to-violet-500",
  },
  {
    code: "Ch 10",
    title: "Vector Algebra",
    questions: 446,
    diff: "Moderate",
    color: "from-emerald-500 to-teal-500",
  },
  {
    code: "Ch 11",
    title: "Three Dimensional Geometry",
    questions: 392,
    diff: "Mardo",
    color: "from-teal-500 to-cyan-500",
  },
  {
    code: "Ch 12",
    title: "Linear Programming",
    questions: 218,
    diff: "Moderate",
    color: "from-fuchsia-500 to-purple-500",
  },
  {
    code: "Ch 13",
    title: "Probability",
    questions: 498,
    diff: "Mardo",
    color: "from-blue-500 to-violet-500",
  },
];

export default function Chapters() {
  const [active, setActive] = useState(6); // Integrals

  return (
    <section id="chapters" className="relative py-24 md:py-32">
      {/* Subtle backdrop */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-violet-950/10 to-transparent" />

      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-2xl text-center"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full glass px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-pink-300">
            Full Syllabus
          </span>
          <h2 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            All 13 chapters.{" "}
            <span className="gradient-text-cool">Zero fluff.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-zinc-400">
            Every chapter of the Class 12 NCERT syllabus mapped — with the
            toughest, board-repeated and concept-breaking questions front and
            centre.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-6 lg:grid-cols-12">
          {/* Chapter list */}
          <div className="lg:col-span-5">
            <div className="grid gap-2 max-h-[560px] overflow-y-auto pr-2 -mr-2 lg:max-h-[640px]">
              {chapters.map((c, i) => (
                <ChapterItem
                  key={c.code}
                  chapter={c}
                  active={active === i}
                  onClick={() => setActive(i)}
                  delay={i * 0.04}
                />
              ))}
            </div>
          </div>

          {/* Showcase panel */}
          <div className="lg:col-span-7">
            <ChapterPanel chapter={chapters[active]} />
          </div>
        </div>
      </div>
    </section>
  );
}

function ChapterItem({
  chapter,
  active,
  onClick,
  delay,
}: {
  chapter: typeof import("./Chapters").default extends never ? never : any;
  active: boolean;
  onClick: () => void;
  delay: number;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, x: -10 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay }}
      onClick={onClick}
      className={`group relative flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all ${
        active
          ? "border-white/20 bg-white/[0.06]"
          : "border-transparent hover:border-white/10 hover:bg-white/[0.03]"
      }`}
    >
      {active && (
        <motion.span
          layoutId="activeChapter"
          className="absolute inset-y-1 left-0 w-1 rounded-r-full bg-gradient-to-b from-violet-400 to-pink-500"
        />
      )}
      <div
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${
          chapter.color
        } text-[11px] font-bold text-white ${active ? "shadow-lg shadow-fuchsia-500/30" : ""}`}
      >
        {chapter.code.split(" ")[1]}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center justify-between gap-2">
          <p
            className={`truncate text-sm font-semibold ${
              active ? "text-white" : "text-zinc-300"
            }`}
          >
            {chapter.title}
          </p>
          <span
            className={`hidden shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide sm:inline-block ${
              chapter.diff === "Mardo"
                ? "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30"
                : "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30"
            }`}
          >
            {chapter.diff}
          </span>
        </div>
        <p className="mt-0.5 text-xs text-zinc-500">
          {chapter.questions} curated questions
        </p>
      </div>
      <ArrowRight
        className={`h-4 w-4 shrink-0 transition-all ${
          active
            ? "translate-x-0 text-white opacity-100"
            : "-translate-x-2 text-zinc-500 opacity-0 group-hover:translate-x-0 group-hover:opacity-100"
        }`}
      />
    </motion.button>
  );
}

function ChapterPanel({ chapter }: { chapter: (typeof chapters)[number] }) {
  return (
    <motion.div
      key={chapter.code}
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="sticky top-28 overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-white/[0.01] p-6 md:p-8"
    >
      <div
        className={`absolute -top-32 -right-32 h-72 w-72 rounded-full bg-gradient-to-br ${chapter.color} opacity-20 blur-3xl`}
      />
      <div className="relative">
        <div className="flex items-center justify-between">
          <div
            className={`inline-flex items-center gap-2 rounded-xl bg-gradient-to-br ${chapter.color} px-3 py-1.5 text-xs font-bold text-white shadow-lg`}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-white" />
            {chapter.code} · Class 12 CBSE
          </div>
          <span
            className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide ${
              chapter.diff === "Mardo"
                ? "bg-rose-500/15 text-rose-300 ring-1 ring-rose-400/30"
                : "bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30"
            }`}
          >
            {chapter.diff}
          </span>
        </div>

        <h3 className="font-display mt-6 text-3xl font-extrabold text-white md:text-4xl">
          {chapter.title}
        </h3>
        <p className="mt-2 text-zinc-400">
          {chapter.questions} hand-picked questions · sorted by weightage, exam
          frequency and conceptual depth.
        </p>

        <div className="mt-7 grid grid-cols-3 gap-3">
          {[
            { label: "Starter", n: Math.floor(chapter.questions * 0.35) },
            { label: "Moderate", n: Math.floor(chapter.questions * 0.35) },
            { label: "Mardo", n: Math.floor(chapter.questions * 0.3) },
          ].map((t) => (
            <div
              key={t.label}
              className="rounded-xl border border-white/10 bg-black/30 p-3.5 text-center"
            >
              <div className="font-display text-xl font-extrabold text-white">
                {t.n}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-zinc-500">
                {t.label}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-7 rounded-2xl border border-white/10 bg-black/40 p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              Top HOTS from this chapter
            </p>
            <span className="text-[10px] text-zinc-600">3 shown</span>
          </div>
          <div className="space-y-2.5">
            {[
              "Evaluate ∫ (x² + 1) / (x⁴ + x² + 1) dx — board 2023 set",
              "Using integration by parts, find ∫ eˣ · (sin x + cos x) dx",
              "Solve: dy/dx = (x + y + 1)/(x + y − 1) — Bernoulli form",
            ].map((q) => (
              <div
                key={q}
                className="flex items-start gap-2.5 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2.5 text-xs leading-relaxed text-zinc-300"
              >
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                <span>{q}</span>
              </div>
            ))}
          </div>
        </div>

        <a
          href="#cta"
          className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 px-5 py-3.5 text-sm font-semibold text-white shadow-lg shadow-fuchsia-500/30 transition-all hover:shadow-fuchsia-500/50"
        >
          Start this chapter free
          <ArrowRight className="h-4 w-4" />
        </a>
      </div>
    </motion.div>
  );
}

// prevent unused warnings
useEffect;
