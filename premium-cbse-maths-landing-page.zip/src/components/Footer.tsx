import { Sparkles, Send, MessageCircle, Globe, Phone } from "lucide-react";

const cols = [
  {
    title: "Product",
    links: [
      "Features",
      "All chapters",
      "Mock tests",
      "AI doubt solver",
      "Mobile app",
    ],
  },
  {
    title: "Resources",
    links: [
      "Sample papers",
      "Solutions PDF",
      "Formula sheets",
      "Study planner",
      "Blog",
    ],
  },
  {
    title: "Company",
    links: ["About", "Team", "Careers", "Press", "Contact"],
  },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/[0.06] bg-[#050509] pt-16 md:pt-20">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/30 to-transparent" />

      <div className="mx-auto max-w-7xl px-5 pb-10">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <a href="#top" className="inline-flex items-center gap-2.5">
              <div className="relative">
                <div className="absolute -inset-1 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 opacity-70 blur-md" />
                <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 shadow-lg shadow-violet-500/40">
                  <Sparkles className="h-5 w-5 text-white" strokeWidth={2.5} />
                </div>
              </div>
              <span className="font-display text-base font-bold tracking-tight text-white">
                Mardo Wale Sawaal
              </span>
            </a>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-zinc-400">
              The most-loved CBSE Class 12 Maths HOTS platform — built by IIT
              alumni, validated by 1,400+ school toppers in 2025.
            </p>

            <div className="mt-7 flex items-center gap-2">
              {[Send, MessageCircle, Globe, Phone].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.02] text-zinc-400 transition-colors hover:bg-white/[0.08] hover:text-white"
                  aria-label="social link"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {cols.map((c) => (
            <div key={c.title} className="lg:col-span-2">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-500">
                {c.title}
              </p>
              <ul className="mt-5 space-y-3">
                {c.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="text-sm text-zinc-300 transition-colors hover:text-white"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-1">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-500">
              Legal
            </p>
            <ul className="mt-5 space-y-3">
              {["Terms", "Privacy", "Refunds"].map((l) => (
                <li key={l}>
                  <a
                    href="#"
                    className="text-sm text-zinc-300 transition-colors hover:text-white"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 sm:flex-row">
          <p className="text-xs text-zinc-500">
            © {new Date().getFullYear()} Mardo Wale Sawaal · Made with focus
            in Bengaluru 🇮🇳
          </p>
          <div className="flex items-center gap-4 text-xs text-zinc-500">
            <span className="flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              All systems operational
            </span>
            <span>·</span>
            <span>CBSE Class 12 · 2025–26</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
