import { motion } from "framer-motion";
import {
  ArrowRight,
  Sparkles,
  Play,
  Star,
  CheckCircle2,
} from "lucide-react";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative isolate overflow-hidden pb-24 pt-36 md:pb-32 md:pt-44"
    >
      <div className="aurora" />

      {/* Background grid */}
      <div className="bg-grid pointer-events-none absolute inset-0 z-0 opacity-50" />

      <div className="relative z-10 mx-auto max-w-7xl px-5">
        <div className="grid items-center gap-14 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs font-medium"
            >
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              <span className="text-zinc-200">
                Boards 2026 — Now with{" "}
                <span className="gradient-text-brand font-semibold">
                  1,200+ new HOTS
                </span>
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="font-display mt-6 text-5xl font-extrabold leading-[0.95] tracking-tight text-white sm:text-6xl md:text-7xl lg:text-[5.5rem]"
            >
              Tough{" "}
              <span className="gradient-text-brand">CBSE Class 12</span>{" "}
              <br className="hidden sm:block" />
              Maths questions.{" "}
              <span className="relative inline-block">
                <span className="gradient-text-cool">Actually solved.</span>
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  viewBox="0 0 300 12"
                  fill="none"
                  preserveAspectRatio="none"
                >
                  <motion.path
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 1.4, delay: 1 }}
                    d="M2 9 Q 80 -2, 150 6 T 298 4"
                    stroke="url(#hero-underline)"
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                  />
                  <defs>
                    <linearGradient id="hero-underline" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#a78bfa" />
                      <stop offset="100%" stopColor="#f472b6" />
                    </linearGradient>
                  </defs>
                </svg>
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-7 max-w-xl text-lg leading-relaxed text-zinc-300 md:text-xl"
            >
              HOTS, board-style toughies and the{" "}
              <span className="font-medium text-white">
                mardo wale sawaal
              </span>{" "}
              from every chapter of the NCERT — solved step-by-step with
              examiner-style reasoning. Built for students aiming{" "}
              <span className="font-semibold text-white">95+ in boards.</span>
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center"
            >
              <a
                href="#cta"
                className="group relative inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 px-7 py-4 text-base font-semibold text-white shadow-2xl shadow-fuchsia-500/40 transition-all hover:scale-[1.02] hover:shadow-fuchsia-500/60"
              >
                <Sparkles className="h-5 w-5" />
                Start solving free
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#showcase"
                className="group inline-flex items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-6 py-4 text-base font-medium text-white backdrop-blur transition-all hover:bg-white/10"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white text-violet-600 transition-transform group-hover:scale-110">
                  <Play className="h-3.5 w-3.5 fill-violet-600" />
                </span>
                See a sample question
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-zinc-400"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>No credit card needed</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>13 chapters, all units</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>Hindi + English</span>
              </div>
            </motion.div>
          </div>

          {/* Visual */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative lg:col-span-5"
          >
            <HeroVisual />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function HeroVisual() {
  return (
    <div className="relative">
      {/* Floating ambient blobs */}
      <div className="absolute -top-10 -left-10 h-40 w-40 rounded-full bg-violet-500/30 blur-3xl" />
      <div className="absolute -bottom-10 -right-10 h-44 w-44 rounded-full bg-pink-500/30 blur-3xl" />

      {/* Main card */}
      <div className="relative">
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="glass-strong relative overflow-hidden rounded-3xl p-6 shadow-2xl shadow-violet-900/40"
        >
          {/* Top bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-2.5 w-2.5 rounded-full bg-rose-400/80" />
              <div className="h-2.5 w-2.5 rounded-full bg-amber-400/80" />
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-400/80" />
            </div>
            <div className="rounded-full bg-fuchsia-500/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-fuchsia-300 ring-1 ring-fuchsia-400/30">
              HOTS • 6 marks
            </div>
          </div>

          {/* Chapter */}
          <div className="mt-5 flex items-center gap-2 text-xs text-zinc-400">
            <span className="rounded-md bg-white/5 px-2 py-0.5 font-mono">
              Ch 7
            </span>
            <span>Integrals · CBSE 2024 board</span>
          </div>

          {/* Question */}
          <h3 className="mt-3 font-display text-base font-semibold leading-snug text-white md:text-lg">
            Evaluate{" "}
            <span className="gradient-text-brand font-bold">
              ∫ e<sup>x</sup> · (tan x + sec²x) dx
            </span>{" "}
            using integration by parts.
          </h3>

          {/* Stepwise solution */}
          <div className="mt-5 space-y-2.5">
            {[
              { label: "Let I = ∫ eˣ(tan x + sec²x) dx", color: "text-zinc-300" },
              { label: "= ∫ eˣ tan x dx + ∫ eˣ sec²x dx", color: "text-zinc-300" },
              {
                label: "Apply by parts to first integral: u = tan x, dv = eˣ dx",
                color: "text-violet-300",
              },
              { label: "Simplify to: eˣ(tan x − 1) + eˣ tan x + C", color: "text-pink-300" },
              { label: "Final: eˣ(2 tan x − 1) + C", color: "text-emerald-300 font-semibold" },
            ].map((step, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + i * 0.18 }}
                className="flex items-start gap-3 rounded-lg border border-white/5 bg-black/30 px-3 py-2"
              >
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-violet-500/30 to-pink-500/30 text-[10px] font-bold text-white">
                  {i + 1}
                </span>
                <code className={`text-xs leading-relaxed ${step.color}`}>
                  {step.label}
                </code>
              </motion.div>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-5 flex items-center justify-between border-t border-white/5 pt-4 text-xs">
            <div className="flex items-center gap-1.5 text-zinc-400">
              <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
              <span>Examiner-validated</span>
            </div>
            <div className="flex items-center gap-1.5 text-zinc-400">
              <div className="flex -space-x-1">
                <div className="h-5 w-5 rounded-full bg-gradient-to-br from-violet-400 to-pink-500 ring-2 ring-[#0d0d18]" />
                <div className="h-5 w-5 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 ring-2 ring-[#0d0d18]" />
                <div className="h-5 w-5 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 ring-2 ring-[#0d0d18]" />
              </div>
              <span>4,812 students</span>
            </div>
          </div>
        </motion.div>

        {/* Floating chips */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.1, type: "spring" }}
          className="absolute -left-6 top-1/3 hidden rounded-2xl border border-white/10 bg-[#0d0d18]/90 px-3.5 py-2.5 backdrop-blur-md shadow-2xl md:block"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
              ✓
            </div>
            <div className="leading-tight">
              <p className="text-[11px] font-semibold text-white">Score: 6/6</p>
              <p className="text-[10px] text-zinc-400">Aarav • DPS RKP</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.3, type: "spring" }}
          className="absolute -right-4 bottom-10 hidden rounded-2xl border border-white/10 bg-[#0d0d18]/90 px-3.5 py-2.5 backdrop-blur-md shadow-2xl md:block"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-500/20 text-violet-300">
              🔥
            </div>
            <div className="leading-tight">
              <p className="text-[11px] font-semibold text-white">12-day streak</p>
              <p className="text-[10px] text-zinc-400">Keep going!</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
